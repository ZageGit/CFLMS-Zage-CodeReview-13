<?php
namespace App\Controller;

// We need to import Response, Route, Request and Controller if we want to use them
use Symfony\ Component\HttpFoundation\Response;
use  Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\ HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;


use Symfony\Component\Form\Extension\Core\Type\TextType ;
use Symfony\Component\Form\Extension\Core\Type\TextareaType ;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\ Component\Form\Extension\Core\Type\ChoiceType;
use  Symfony\Component\Form\Extension\Core\Type\SubmitType;
use  Symfony\Component\Form\Extension\Core\Type\IntegerType;
use  Symfony\Component\Form\Extension\Core\Type\EmailType;
use  Symfony\Component\Form\Extension\Core\Type\TelType;
use App\Entity\Events ;


class EventsController extends AbstractController
{
            /**
    * @Route("/", name="indexAction")
    */ 
    public  function indexAction()
    {
        $events = $this->getDoctrine()
            ->getRepository(Events::class)
            ->findAll(); // this variable $products will store the result of running a query to find all the products
         return $this->render('events/index.html.twig', array("events"=>$events)); // i send the variable that have all the products as an array of objects to the index.html.twig page
    }

    /**
    * @Route("/create", name="create_page")
    */
  /**
    * @Route("/create", name="create_page")
    */
    public function  createAction(Request $request)
   {
        // Here we create an object from the class that we made
       $event = new Events;
/* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
    $form = $this->createFormBuilder($event)
    ->add( 'name', TextType::class, array ('attr' => array ('class'=> 'form-control' , 'style'=> 'margin-bottom:15px',)))
    ->add( 'date' , DateTimeType::class, array ( 'attr'  => array ('class'=> 'input-group date' ,'style' => 'margin-bottom:15px' )))
    ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
    ->add( 'image', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add('capacity', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('email', EmailType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('phone', TelType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('street', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add('streetNr', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('zipCode', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('city', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add('url', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add( 'type' , ChoiceType::class, array ( 'choices' => array ( 'Music' => 'Music' , 'Theater' => 'Theater' , 'Comedy' => 'Comedy' ), 'attr'  => array ( 'class' => 'form-control' , 'style' => 'margin-botton:15px' )))
    ->add( 'save' , SubmitType::class, array ( 'label' => 'Create Event' , 'attr'  => array ( 'class' => 'btn btn-primary mt-4' , 'style' => 'margin-bottom:15px' )))
    ->getForm();
    $form->handleRequest($request);
       

        /* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
        if ($form->isSubmitted() && $form->isValid()){
            //fetching data

            // taking the data from the inputs by the name of the inputs then getData() function
           $name = $form[ 'name' ]->getData();
           $date = $form[ 'date' ]->getData();
           $description = $form[ 'description' ]->getData();
           $image = $form[ 'image' ]->getData();
           $capacity = $form[ 'capacity' ]->getData();
           $email = $form[ 'email' ]->getData();
           $phone = $form[ 'phone' ]->getData();
           $street = $form[ 'street' ]->getData();
           $streetNr = $form[ 'streetNr' ]->getData();
           $zipCode = $form[ 'zipCode' ]->getData();
           $city = $form[ 'city' ]->getData();
           $url = $form[ 'url' ]->getData();
           $type = $form[ 'type' ]->getData();
           

/* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
           $event->setName($name);
           $event->setDate($date);
           $event->setDescription($description);
           $event->setImage($image);
           $event->setCapacity($capacity);
           $event->setEmail($email);
           $event->setPhone($phone);
           $event->setStreetNr($streetNr);
           $event->setZipCode($zipCode);
           $event->setCity($city);
           $event->setUrl($url);
           $event->setType($type);
           $em = $this ->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
            $this ->addFlash(
                    'notice' ,
                    'event Added'
                   );
            return   $this ->redirectToRoute( 'index' );
       }
/* now to make the form we will add this line form->createView() and now you can see the form in create.html.twig file  */
        return   $this ->render( 'events/create.html.twig' , array ( 'form'  => $form->createView()));
   }

 /**
    * @Route("/edit/{id}", name="event_edit")
    */
    public  function editAction( $id, Request $request){
        /* Here we have a variable todo and it will save the result of this search and it will be one result because we search based on a specific id */
        $event = $this->getDoctrine()->getRepository('App:Events')->find($id);

        /* Now we will use set functions and inside this set functions we will bring the value that is already exist using get function for example we have setName() and inside it we will bring the current value and use it again */
        $event->setName($event->getName());
        $event->setDate($event->getDate());
        $event->setDescription($event->getDescription());
        $event->setImage($event->getImage());
        $event->setCapacity($event->getCapacity());
        $event->setEmail($event->getEmail());
        $event->setPhone($event->getPhone());
        $event->setStreetNr($event->getStreetNr());
        $event->setZipCode($event->getZipCode());
        $event->setCity($event->getCity());
        $event->setUrl($event->getUrl());
        $event->setType($event->getType());



     /* Now when you type createFormBuilder and you will put the variable todo the form will be filled of the data that you already set it */
            $form = $this->createFormBuilder($event)
            ->add( 'name', TextType::class, array ('attr' => array ('class'=> 'form-control' , 'style'=> 'margin-bottom:15px',)))
            ->add( 'date' , DateTimeType::class, array ( 'attr'  => array ('class'=> 'input-group date' ,'style' => 'margin-bottom:15px' )))
            ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
            ->add( 'image', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add('capacity', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('email', EmailType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('phone', TelType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('street', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add('streetNr', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('zipCode', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('city', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add('url', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'type' , ChoiceType::class, array ( 'choices' => array ( 'Music' => 'Music' , 'Theater' => 'Theater' , 'Comedy' => 'Comedy' ), 'attr'  => array ( 'class' => 'form-control' , 'style' => 'margin-botton:15px' )))
            ->add( 'save' , SubmitType::class, array ( 'label' => 'Update Event' , 'attr'  => array ( 'class' => 'btn btn-primary mt-4' , 'style' => 'margin-bottom:15px' )))
                    ->getForm();
               $form->handleRequest($request);
                if($form->isSubmitted() && $form->isValid()){
                    //fetching data
                    $name = $form[ 'name' ]->getData();
                    $date = $form[ 'date' ]->getData();
                    $description = $form[ 'description' ]->getData();
                    $image = $form[ 'image' ]->getData();
                    $capacity = $form[ 'capacity' ]->getData();
                    $email = $form[ 'email' ]->getData();
                    $phone = $form[ 'phone' ]->getData();
                    $street = $form[ 'street' ]->getData();
                    $streetNr = $form[ 'streetNr' ]->getData();
                    $zipCode = $form[ 'zipCode' ]->getData();
                    $city = $form[ 'city' ]->getData();
                    $url = $form[ 'url' ]->getData();
                    $type = $form[ 'type' ]->getData();


                    $event->setName($name);
                    $event->setDate($date);
                    $event->setDescription($description);
                    $event->setImage($image);
                    $event->setCapacity($capacity);
                    $event->setEmail($email);
                    $event->setPhone($phone);
                    $event->setStreetNr($streetNr);
                    $event->setZipCode($zipCode);
                    $event->setCity($city);
                    $event->setUrl($url);
                    $event->setType($type);
                    $em = $this->getDoctrine()->getManager();
                   $em->flush();
                    $this->addFlash(
                            'notice',
                            'Event Updated'
                           );
                    return $this ->redirectToRoute('index' );
               }
               return  $this->render( 'events/edit.html.twig', array( 'event' => $event, 'form' => $form->createView()));
           }
    /**
    * @Route("/details/{id}", name="details_page")
    */
   public  function detailsAction($id)
   {
       $event = $this->getDoctrine()->getRepository('App:Events')->find($id);
        return $this->render('events/details.html.twig', array('event'=>$event));
   }

      /**
    * @Route("/delete/{id}", name="event_delete")
    */
    public function deleteAction($id){
    $em = $this->getDoctrine()->getManager();
   $event = $em->getRepository('App:Events')->find($id);
   $em->remove($event);
    $em->flush();
    $this->addFlash(
           'notice',
            'Event Removed'
           );
    return  $this->redirectToRoute('index');
}
}
?>