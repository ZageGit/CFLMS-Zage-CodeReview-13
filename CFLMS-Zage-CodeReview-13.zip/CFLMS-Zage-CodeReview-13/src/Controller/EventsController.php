<?php
namespace App\Controller;

// Importing Response Rout Request and Controller
use Symfony\ Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

// Importing Formbuilder Components (FieldTypes)
use Symfony\Component\Form\Extension\Core\Type\TextType ;
use Symfony\Component\Form\Extension\Core\Type\TextareaType ;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TelType;
use App\Entity\Events ;// Ipmorting Events Entity



class EventsController extends AbstractController
{
            /**
    * @Route("/", name="indexAction")
    */ 
    public  function indexAction() //function to display all Events on index twig
    {
        $events = $this->getDoctrine()
        ->getRepository(Events::class)
        ->findAll();
         return $this->render('events/index.html.twig', array("events"=>$events)); 
            }

    /**
    * @Route("/create", name="create_page")
    */
  /**
    * @Route("/create", name="create_page")
    */
    public function  createAction(Request $request)
   {
       //Creating Formbuilder Input Fields
    $event = new Events;
    $form = $this->createFormBuilder($event)
    ->add( 'name', TextType::class, array ('attr' => array ('class'=> 'form-control' , 'style'=> 'margin-bottom:15px',)))
    ->add( 'date' , DateTimeType::class, array ( 'attr'  => array ('class'=> 'input-group date' ,'style' => 'margin-bottom:15px' )))
    ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
    ->add( 'image', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add('capacity', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('email', EmailType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('phone', TelType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('street', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add('streetNr', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('zipCode', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
    ->add('city', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add('url', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add( 'type' , ChoiceType::class, array ( 'choices' => array ( 'Music' => 'Music' , 'Theater' => 'Theater' , 'Comedy' => 'Comedy' ), 'attr'  => array ( 'class' => 'form-control' , 'style' => 'margin-botton:15px' )))
    ->add( 'save' , SubmitType::class, array ( 'label' => 'Create Event' , 'attr'  => array ( 'class' => 'btn btn-primary mt-4' , 'style' => 'margin-bottom:15px' )))
    ->getForm();
    $form->handleRequest($request);
       

        /* If statement if Input is submitted and valid */
        if ($form->isSubmitted() && $form->isValid()){
            //fetching data

            // taking the data from the inputs by the name of the inputs then getData() function
           $name = $form[ 'name' ]->getData();
           $date = $form[ 'date' ]->getData();
           $description = $form[ 'description' ]->getData();
           $image = $form[ 'image' ]->getData();
           $capacity = $form[ 'capacity' ]->getData();
           $email = $form[ 'email' ]->getData();
           $phone = $form[ 'phone' ]->getData();
           $street = $form[ 'street' ]->getData();
           $streetNr = $form[ 'streetNr' ]->getData();
           $zipCode = $form[ 'zipCode' ]->getData();
           $city = $form[ 'city' ]->getData();
           $url = $form[ 'url' ]->getData();
           $type = $form[ 'type' ]->getData();
           

/* bringing get() Functions from Entity and putting in variables */
           $event->setName($name);
           $event->setDate($date);
           $event->setDescription($description);
           $event->setImage($image);
           $event->setCapacity($capacity);
           $event->setEmail($email);
           $event->setPhone($phone);
           $event->setStreetNr($streetNr);
           $event->setZipCode($zipCode);
           $event->setCity($city);
           $event->setUrl($url);
           $event->setType($type);
           $em = $this ->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
            $this ->addFlash(
                    'notice' ,
                    'event Added'
                   );
            return   $this ->redirectToRoute( 'index' );
       }
/* createing and render form in twig  */
        return   $this ->render( 'events/create.html.twig' , array ( 'form'  => $form->createView()));
   }

 /**
    * @Route("/edit/{id}", name="event_edit")
    */
    public  function editAction( $id, Request $request){ /*function for editing events entity */
        $event = $this->getDoctrine()->getRepository('App:Events')->find($id);

        /* setting existing values into input fields */
        $event->setName($event->getName());
        $event->setDate($event->getDate());
        $event->setDescription($event->getDescription());
        $event->setImage($event->getImage());
        $event->setCapacity($event->getCapacity());
        $event->setEmail($event->getEmail());
        $event->setPhone($event->getPhone());
        $event->setStreetNr($event->getStreetNr());
        $event->setZipCode($event->getZipCode());
        $event->setCity($event->getCity());
        $event->setUrl($event->getUrl());
        $event->setType($event->getType());



       //Creating Formbuilder Input Fields
            $form = $this->createFormBuilder($event)
            ->add( 'name', TextType::class, array ('attr' => array ('class'=> 'form-control' , 'style'=> 'margin-bottom:15px',)))
            ->add( 'date' , DateTimeType::class, array ( 'attr'  => array ('class'=> 'input-group date' ,'style' => 'margin-bottom:15px' )))
            ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
            ->add( 'image', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add('capacity', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('email', EmailType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('phone', TelType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('street', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add('streetNr', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('zipCode', IntegerType::class, array ('attr' => array('class'=>'form-control', 'style'=> 'margin-bottom:15px')))
            ->add('city', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add('url', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'type' , ChoiceType::class, array ( 'choices' => array ( 'Music' => 'Music' , 'Theater' => 'Theater' , 'Comedy' => 'Comedy' ), 'attr'  => array ( 'class' => 'form-control' , 'style' => 'margin-botton:15px' )))
            ->add( 'save' , SubmitType::class, array ( 'label' => 'Update Event' , 'attr'  => array ( 'class' => 'btn btn-primary mt-4' , 'style' => 'margin-bottom:15px' )))
                    ->getForm();
               $form->handleRequest($request);
                if($form->isSubmitted() && $form->isValid()){
                    //fetching data
                    $name = $form[ 'name' ]->getData();
                    $date = $form[ 'date' ]->getData();
                    $description = $form[ 'description' ]->getData();
                    $image = $form[ 'image' ]->getData();
                    $capacity = $form[ 'capacity' ]->getData();
                    $email = $form[ 'email' ]->getData();
                    $phone = $form[ 'phone' ]->getData();
                    $street = $form[ 'street' ]->getData();
                    $streetNr = $form[ 'streetNr' ]->getData();
                    $zipCode = $form[ 'zipCode' ]->getData();
                    $city = $form[ 'city' ]->getData();
                    $url = $form[ 'url' ]->getData();
                    $type = $form[ 'type' ]->getData();


                    $event->setName($name);
                    $event->setDate($date);
                    $event->setDescription($description);
                    $event->setImage($image);
                    $event->setCapacity($capacity);
                    $event->setEmail($email);
                    $event->setPhone($phone);
                    $event->setStreetNr($streetNr);
                    $event->setZipCode($zipCode);
                    $event->setCity($city);
                    $event->setUrl($url);
                    $event->setType($type);
                    $em = $this->getDoctrine()->getManager();
                   $em->flush();
                    $this->addFlash(
                            'notice',
                            'Event Updated'
                           );
                    return $this ->redirectToRoute('index' );
               }
               return  $this->render( 'events/edit.html.twig', array( 'event' => $event, 'form' => $form->createView()));
           }
    /**
    * @Route("/details/{id}", name="details_page")
    */
   public  function detailsAction($id) /* fucntion to display single events on details twig*/
   {
       $event = $this->getDoctrine()->getRepository('App:Events')->find($id);
        return $this->render('events/details.html.twig', array('event'=>$event));
   }

      /**
    * @Route("/delete/{id}", name="event_delete")
    */
    public function deleteAction($id){ /*delete function */
    $em = $this->getDoctrine()->getManager();
   $event = $em->getRepository('App:Events')->find($id);
   $em->remove($event);
    $em->flush();
    $this->addFlash(
           'notice',
            'Event Removed'
           );
    return  $this->redirectToRoute('index');
}

public  function categoryAction($type){ /* Function to display events by type*/
    $events = $this->getDoctrine()
    ->getRepository(Events::class)
    ->findByType($type);
     return $this->render('events/category.html.twig', array("events"=>$events, "type"=>$type)); // i send the variable that have all the products as an array of objects to the index.html.twig page
}

}
?>